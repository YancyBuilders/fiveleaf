import{t as e}from"./base-BFouKPZd.js";var t=new class extends e{async beautify(){let e=this.getOptionValue(`tab`,4),t=this.code.split(`
`),n=[],r=0;for(let i of t){let t=i.trim(),a=(t.match(/^[})\]]/g)||[]).length;r=Math.max(0,r-a),n.push(` `.repeat(r*e)+t);let o=(t.match(/[{([][^})\]]*$/g)||[]).length;r+=o}return n.join(`
`)}async compress(){return this.code}};export{t as formatter};