import{c as e}from"./index-BKafOP8J.js";import{t}from"./base-BFouKPZd.js";var n=new class extends t{async beautify(){let t=e.parse(this.code,{joiner:`
`});return e.stringify(t,{newline:`
`,integer:2**53-1})}async compress(){return this.code}};export{n as formatter};